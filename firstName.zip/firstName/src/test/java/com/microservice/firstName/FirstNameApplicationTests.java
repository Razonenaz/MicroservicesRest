package com.microservice.firstName;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstNameApplicationTests {

	@Test
	void contextLoads() {
	}

}
