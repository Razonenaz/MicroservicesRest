package com.microservice.firstName.repository;

import org.bson.conversions.Bson;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;

public class FirstNameRepository {
	MongoCollection<?> collection;

	public FirstNameRepository() {
		collection = DBContext.fetchCollection("mongodb://localhost:27017", "Students", "student");
	}

	public String getFirstNameById(long id) {
		Bson filter = Filters.eq("id", id);
		Bson projection = Projections.fields(Projections.include("firstName"));

		return collection.find(filter).projection(projection).toString();
	}

	public String addFirstName(long id, String firstName) {
		Bson filter = Filters.eq("id", id);
		Bson update = Updates.set("firstName", firstName);

		collection.updateOne(filter, update).toString();

		return "First name added";
	}

	public String updateFirstName(long id, String firstName) {
		Bson filter = Filters.eq("id", id);
		Bson update = Updates.set("firstName", firstName);

		collection.updateOne(filter, update).toString();

		return "First name updated";
	}

	public String deleteFirstName(long id) {
		Bson filter = Filters.eq("id", id);
		Bson update = Updates.set("firstName", null);

		collection.updateOne(filter, update).toString();

		return "First name deleted";
	}
}
