package com.microservice.firstName.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.firstName.repository.FirstNameRepository;

@Service
public class FirstNameService {

	@Autowired
	private FirstNameRepository repository;

	public String getFirstNameById(long id) {

		return repository.getFirstNameById(id);
	}

	public String addFirstName(long id, String firstName) {

		return repository.addFirstName(id, firstName);
	}

	public String updateFirstNameById(long id, String firstName) {

		return repository.updateFirstName(id, firstName);
	}

	public String deleteFirstNameById(long id) {

		return repository.deleteFirstName(id);
	}
}
