package com.microservice.lastName.repository;

import org.bson.conversions.Bson;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;

public class LastNameRepository {
	MongoCollection<?> collection;

	public LastNameRepository() {
		collection = DBContext.fetchCollection("mongodb://localhost:27017", "Students", "student");
	}

	public String getLastNameById(long id) {
		Bson filter = Filters.eq("id", id);
		Bson projection = Projections.fields(Projections.include("lastName"));

		return collection.find(filter).projection(projection).toString();
	}

	public String addLastName(long id, String lastName) {
		Bson filter = Filters.eq("id", id);
		Bson update = Updates.set("lastName", lastName);

		collection.updateOne(filter, update).toString();

		return "Last name added";
	}

	public String updateLastName(long id, String lastName) {
		Bson filter = Filters.eq("id", id);
		Bson update = Updates.set("lastName", lastName);

		collection.updateOne(filter, update).toString();

		return "Last name updated";
	}

	public String deleteLastName(long id) {
		Bson filter = Filters.eq("id", id);
		Bson update = Updates.set("lastName", null);

		collection.updateOne(filter, update).toString();

		return "Last name deleted";
	}
}
