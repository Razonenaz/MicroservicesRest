package com.microservice.lastName;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LastNameApplication {

	public static void main(String[] args) {
		SpringApplication.run(LastNameApplication.class, args);
	}

}
