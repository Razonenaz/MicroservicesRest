package com.microservice.lastName.model;

import org.springframework.data.annotation.Id;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Student {

    @Id
    private Long id;
    private String lastName;
}
