package com.microservice.middleName;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiddleNameApplicationTests {

	@Test
	void contextLoads() {
	}

}
