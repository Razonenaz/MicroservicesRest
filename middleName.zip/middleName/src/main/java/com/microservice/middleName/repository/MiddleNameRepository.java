package com.microservice.middleName.repository;

import org.bson.conversions.Bson;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;

public class MiddleNameRepository {
	MongoCollection<?> collection;

	public MiddleNameRepository() {
		collection = DBContext.fetchCollection("mongodb://localhost:27017", "Students", "student");
	}

	public String getMiddleNameById(long id) {
		Bson filter = Filters.eq("id", id);
		Bson projection = Projections.fields(Projections.include("middleName"));

		return collection.find(filter).projection(projection).toString();
	}

	public String addMiddleName(long id, String middleName) {
		Bson filter = Filters.eq("id", id);
		Bson update = Updates.set("middleName", middleName);

		collection.updateOne(filter, update).toString();

		return "Middle name added";
	}

	public String updateMiddleName(long id, String middleName) {
		Bson filter = Filters.eq("id", id);
		Bson update = Updates.set("middleName", middleName);

		collection.updateOne(filter, update).toString();

		return "Middle name updated";
	}

	public String deleteMiddleName(long id) {
		Bson filter = Filters.eq("id", id);
		Bson update = Updates.set("middleName", null);

		collection.updateOne(filter, update).toString();

		return "Middle name deleted";
	}
}
