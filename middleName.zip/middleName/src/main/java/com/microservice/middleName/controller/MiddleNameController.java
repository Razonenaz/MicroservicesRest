package com.microservice.middleName.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import com.microservice.middleName.model.Student;
import com.microservice.middleName.service.MiddleNameService;

@RestController
public class MiddleNameController {

	@Autowired
	private MiddleNameService service;

	@GetMapping(value = "/student/get/{id}")
	public Student getById(@PathVariable("id") long id) {
		Student student = WebClient.create("http://localhost:8083").get()
				.uri(uriBuilder -> uriBuilder.path("/student/get/{id}").build(id)).retrieve().bodyToMono(Student.class)
				.block();
		String middleName = service.getMiddleName(id);
		student = Student.builder().middleName(middleName).build();

		return student;
	}

	@PostMapping("/student/add/{id}/{middleName}")
	public Student addMiddleName(@PathVariable("id") long id,
			@PathVariable("middleName") String middleName) {

		
		String message = service.addMiddleName(id, middleName);

		return student;
	}

	@PutMapping(value = "/update/{id}/{middleName}")
	public ResponseEntity<String> updateById(@PathVariable("id") long id,
			@PathVariable("middleName") String middleName) {

		String message = service.updateMiddleName(id, middleName);

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}

	@DeleteMapping(value = "delete/{id}")
	public ResponseEntity<String> deleteMiddleName(@PathVariable("id") long id) {

		String message = service.deleteMiddleName(id);

		return new ResponseEntity<String>(message, HttpStatus.OK);
	}
}
